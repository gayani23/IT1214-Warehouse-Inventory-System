public class Item{
	private int id;
	private String name;
	private int quantity;
	
	public Item(int id,String name,int quantity){
		this.id=id;
		this.name=name;
		this.quantity=quantity;
	}
	@Override
	public String toString(){
		return " ||Id: "  + id +  "|| Name: "  + name +  " || Quantity: " + quantity ; 
		
	}
}