import java.util.ArrayList;
import java.util.Scanner;

public class WarehouseSystem{
	public static void main(String[]args){
		ArrayList<Item>inventory = new ArrayList<>();
		
		inventory.add(new Item(101,"Laptop",15));
		inventory.add(new Item(102,"Mouse",45));
		inventory.add(new Item(103,"Keyboard",30));
		
		System.out.println("-----------------------------------------------------");
		System.out.println("   *WAREHOUSE INVENTORY MANAGEMENT SYSTEM*  ");
		System.out.println("-----------------------------------------------------");
		
		for(Item item : inventory){
			System.out.println(item);
		}
		
		System.out.println("---------------------------------------------------");
		System.out.println("Total Item in Stock:"  +  inventory.size () );
		
	}
}